package com.gorba.wcsspoof

import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam

/**
 * Spoofs android.os.Build fields (BRAND / MANUFACTURER) to "samsung",
 * but ONLY inside the process of com.samsung.wearable.watchuniteplugin.
 *
 * Reasoning (see chat history): CapabilityExchangeMessage in that app
 * reads Build.BRAND and sends it verbatim to the paired watch under the
 * JSON key "vender". The watch caches it in SharedPreferences and
 * Samsung Health Monitor (watch side) later checks whether that value
 * contains "samsung" or "verizon" before allowing ECG/BP.
 *
 * Scope is intentionally as narrow as possible: only this one package,
 * only these two fields. No other app on the phone is touched, so this
 * does not affect SafetyNet/Play Integrity, banking apps, or anything
 * else that reads Build.* elsewhere on the device.
 */
class MainHook : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "WCSSpoof"

        // The one package this module is allowed to touch.
        private const val TARGET_PACKAGE = "com.samsung.wearable.watchuniteplugin"

        private const val SPOOF_VALUE = "samsung"
    }

    override fun handleLoadPackage(lpparam: LoadPackageParam) {
        if (lpparam.packageName != TARGET_PACKAGE) {
            return
        }

        Log.i(TAG, "handleLoadPackage: hooking $TARGET_PACKAGE")

        try {
            // XposedHelpers.setStaticObjectField is the standard, well-tested
            // idiom for overwriting `public static final` fields like
            // android.os.Build.BRAND/MANUFACTURER from inside a hooked
            // process. It works even though the fields are declared
            // `final`, because the write happens via the same native/JNI
            // path Xposed/LSPosed already uses for its method hooks, which
            // is not subject to the plain-reflection "final" restriction.
            //
            // This must run in handleLoadPackage(), which fires before the
            // target app's Application.onCreate() / static initializers of
            // its own classes run — i.e. before CapabilityExchangeMessage
            // has a chance to read the original value.
            XposedHelpers.setStaticObjectField(android.os.Build::class.java, "BRAND", SPOOF_VALUE)
            XposedHelpers.setStaticObjectField(android.os.Build::class.java, "MANUFACTURER", SPOOF_VALUE)
            Log.i(TAG, "Build.BRAND / Build.MANUFACTURER overridden to \"$SPOOF_VALUE\" " +
                    "for $TARGET_PACKAGE")
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to spoof Build fields for $TARGET_PACKAGE", t)
        }
    }
}
